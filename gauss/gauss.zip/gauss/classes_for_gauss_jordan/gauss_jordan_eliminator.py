# classes/gauss_jordan_eliminator.py
class GaussJordanEliminator:
    """Performs full Gauss-Jordan elimination → Reduced Row Echelon Form (RREF)"""
    def __init__(self, augmented_matrix):
        self.n = len(augmented_matrix)
        self.M = augmented_matrix
        self.rank = 0
        self.pivot_positions = []

    def eliminate(self):
        print("\n" + "="*80)
        print("           GAUSS-JORDAN ELIMINATION → REDUCED ROW ECHELON FORM")
        print("="*80)
        self._print("Initial Augmented Matrix")

        h = 0  # current pivot row
        for col in range(self.n):
            # Find pivot in column col from row h down
            pivot_row = None
            for i in range(h, self.n):
                if abs(self.M[i][col]) > 1e-10:
                    if pivot_row is None or abs(self.M[i][col]) > abs(self.M[pivot_row][col]):
                        pivot_row = i

            if pivot_row is None:
                continue

            # Swap rows
            if pivot_row != h:
                print(f"\nSwap Row{h+1} ↔ Row{pivot_row+1}")
                self.M[h], self.M[pivot_row] = self.M[pivot_row], self.M[h]
                self._print()

            # Normalize pivot row (divide by pivot)
            pivot = self.M[h][col]
            print(f"\nRow{h+1} ÷ {pivot:.6f}  →  make pivot = 1")
            for j in range(self.n + 1):
                self.M[h][j] /= pivot
            self._print()

            # Eliminate column col in ALL other rows (above and below)
            for i in range(self.n):
                if i != h and abs(self.M[i][col]) > 1e-10:
                    factor = self.M[i][col]
                    print(f"Row{i+1} -= ({factor:.6f}) × Row{h+1}")
                    for j in range(self.n + 1):
                        self.M[i][j] -= factor * self.M[h][j]
                    self.M[i][col] = 0.0
                    self._print()

            self.pivot_positions.append((h, col))
            h += 1

        self.rank = h

        print("\n" + "="*80)
        print(f"           REDUCED ROW ECHELON FORM (RREF) – RANK = {self.rank}")
        print("="*80)
        self._print()

    def _print(self, msg=""):
        if msg:
            print(msg)
        for i, row in enumerate(self.M):
            print(f"R{i+1}:", "  ".join(f"{x:12.6f}" for x in row))
        print()

    def get_rref_result(self):
        return self.M, self.rank, self.pivot_positions