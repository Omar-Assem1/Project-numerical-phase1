# classes/rref_solver.py
class RREFSolver:
    def __init__(self, rref_matrix, rank, n, pivot_positions):
        self.M = rref_matrix
        self.rank = rank
        self.n = n
        self.pivot_cols = {col for _, col in pivot_positions}

    def solve(self):
        # Check for inconsistency: row of zeros with non-zero constant
        for i in range(self.rank, self.n):
            if abs(self.M[i][self.n]) > 1e-8:
                print("\nNO SOLUTION (inconsistent system)")
                print(f"Row {i+1} → 0 = {self.M[i][self.n]:.6f}")
                return

        if self.rank < self.n:
            print(f"\nINFINITE SOLUTIONS ({self.n - self.rank} free variable(s))")
            free_vars = [j+1 for j in range(self.n) if j not in self.pivot_cols]
            print("Free variables:", ", ".join(f"x{v}" for v in free_vars))

            # Optional: show general solution
            print("\nGeneral solution:")
            solution = ["0"] * self.n
            for row, col in self.pivot_positions:
                solution[col] = f"{self.M[row][self.n]:.6f}"
                for free_col in free_vars:
                    coeff = self.M[row][free_col-1]
                    if abs(coeff) > 1e-10:
                        sign = "-" if coeff > 0 else "+"
                        val = abs(coeff)
                        solution[col] += f" {sign} {val:.6f}·x{free_col}"
            for i in range(self.n):
                val = solution[i].strip()
                print(f"x{i+1} = {val if val != '0' else val + ' + 0'}")
            return

        # Unique solution – read directly from RREF
        print("\nUNIQUE SOLUTION:")
        print("-" * 40)
        for i in range(self.n):
            val = self.M[i][self.n]
            print(f"x{i+1} = {val:15.8f}")