import math
from .linear_system import LinearSystem


class Chelosky_LU(LinearSystem) :
    def __init__(self , n , precision = None , tol = None) :
        super().__init__(n , precision , tol)
        

        self.L = [[0.0 for _ in range(n)] for _ in range(n)]
        self.U = [[0.0 for _ in range(n)] for _ in range(n)]
        
    # Must be used in each computation and when we take input from user to 
    # round any result based on significant figures that user input (default = 4 (if user dont add required SF)
    def round_sig(self, x , sig):
        if x == 0:
            return 0.0
        order = math.floor(math.log10(abs(x)))
        factor = 10 ** (order - sig + 1)
        return round(x / factor) * factor
    
    ########## Postive Definite or Not ##########
    def determinant(self , matrix):
        if len(matrix) == 1 :
            return matrix[0][0]
        if len(matrix) == 2 :
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
        
        det = 0 
        for col in range(len(matrix)) :
            sub = [row[:col] + row[col+1:] for row in matrix[1:]]
            det += ((-1) ** col) * matrix[0][col] * self.determinant(sub)
        return det
    def is_postivedef(self):
        n = self.n
        A = [row[:n] for row in self.A]

        for i in range(n):
            det = self.determinant([row[:i+1] for row in A[:i+1]])
            if det <= self.tolerence :
                return False
        return True
    

    ####### LU Using Chelosky Method (if A is Positive Definite Only) ########
    def compute_LU(self):
        if not self.is_complete():
            print("enter all equations brother!")
            return
        if not self.is_postivedef():
            print("Cant compute Chelosky LU (Not postive definite)")
            return
        
        
        n = self.n
        A = [row[:n] for row in self.A]


        for j in range(n):
            print(f"--- Column j = {j} ---")
            for i in range(j , n):
                if i == j :
                    sum_LU = sum(self.round_sig((self.L[i][k] ** 2 ), self.precision ) for k in range(i))

                    value = self.round_sig(A[i][j] - sum_LU , self.precision)
                    
                    self.L[i][j] = math.sqrt(value)

                    self.L[i][j] = self.round_sig(self.L[i][j], self.precision)
                    
                    print(f"L[{i}][{j}] = sqrt(A[{i}][{j}] - Σ(L[{i}][k]^2, k=0..{i-1}))")
                    print(f"       = sqrt({A[i][j]} - {sum_LU}) = {self.L[i][j]}")

                    

                else :
                    sum_LU = sum(self.round_sig(self.L[i][k] * self.L[j][k], self.precision)  for k in range(j))

                    value = self.round_sig((A[i][j] - sum_LU) , self.precision) 
                    
                    if self.L[j][j] < self.tolerence :
                        print("Cannot compute LU (Zero pivot or singular matrix)")
                        return
                    self.L[i][j] = self.round_sig((value / self.L[j][j]) , self.precision)
                    
                    print(f"L[{i}][{j}] = (A[{i}][{j}] - Σ(L[{i}][k]*L[{j}][k], k=0..{j-1})) / L[{j}][{j}]")
                    print(f"       = ({A[i][j]} - {sum_LU}) / {self.L[j][j]} = {self.L[i][j] : .{self.precision}g}")

        
            print("\nCurrent L:")
            for row in self.L:
                print([self.round_sig(val, self.precision) for val in row])
            print("\n")
            

        print("U = L(transpose)")
        for i in range(n):
            for j in range(n):
                self.U[i][j] = self.L[j][i]

        for row in self.U:
                print(row)

        return self.L , self.U
    
    def solve(self):

        if not self.is_postivedef():
            print("There is No Chelosky so You cant solve")
            return
        
        b = [row[self.n] for row in self.A]
        n = len(b)

        

        # Step 1
        y = [0.0] * n
        for i in range(n):
            s = sum(self.round_sig(self.L[i][j] * y[j], self.precision) for j in range(i))
            y[i] = self.round_sig(((b[i] - s) / self.L[i][i]) , self.precision)

        # Step 2
        x = [0.0] * n
        for i in range(n - 1, -1, -1):
            s = sum(self.round_sig(self.U[i][j] * x[j], self.precision) for j in range(i + 1, n))
            x[i] = self.round_sig((y[i] - s) / self.U[i][i] , self.precision)
        
        return x
    

