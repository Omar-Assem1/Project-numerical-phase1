import math
from gauss.linear_system import LinearSystem


class Crout_LU(LinearSystem) :
    def __init__(self , n , precision = None , tol = None) :
        super().__init__(n , precision , tol)

        self.L = [[0.0 for _ in range(n)] for _ in range(n)]
        self.U = [[0.0 for _ in range(n)] for _ in range(n)]
    
    # Must be used in each computation and when we take input from user to 
    # round any result based on significant figures that user input (default = 4 (if user dont add required SF))
    def round_sig(self, x, sig):
        if x == 0:
            return 0.0
        order = math.floor(math.log10(abs(x)))
        factor = 10 ** (order - sig + 1)
        return round(x / factor) * factor
    
    ####### LU Using Crout Method ########
    def compute_LU(self):
        if not self.is_complete():
            print("enter all equations brother!")
            return
        
        
        n = self.n
        A = [row[:n] for row in self.A]

        for i in range(n) :
            self.U[i][i] = 1.0

        for j in range(n):
            print(f"--- Column j = {j} ---")
            for i in range(j , n):
                sum_LU = sum(self.round_sig(self.L[i][k] * self.U[k][j],self.precision) for k in range(j))

                value = A[i][j] - sum_LU

                self.L[i][j] = self.round_sig(value , self.precision)
                
                print(f"L[{i}][{j}] = A[{i}][{j}] - Σ(L[{i}][k]*U[k][{j}], k=0..{j-1})")
                print(f"       = {A[i][j]} - {sum_LU} = {self.L[i][j]}")
                

            for i in range(j + 1 , n):
                sum_LU = sum(self.round_sig(self.L[j][k] * self.U[k][i] , self.precision) for k in range(j))
                if self.L[j][j] < self.tolerence :
                    print("Cannot compute LU (Zero pivot or singular matrix)")
                    return
                value = ( A[j][i] - sum_LU ) / self.L[j][j]
                self.U[j][i] = self.round_sig(value , self.precision)

                
                print(f"U[{j}][{i}] = (A[{j}][{i}] - Σ(L[{j}][k]*U[k][{i}], k=0..{j-1})) / L[{j}][{j}]")
                print(f"       = ({A[j][i]} - {sum_LU}) / {self.L[j][j]} = {self.U[j][i]}")

            
            print("\nCurrent L:")
            for row in self.L:
                print(row)
            print("Current U:")
            for row in self.U:
                print(row)
            print("\n")

    # Solving system of linear equations using LU and B
    def solve(self):
    
        b = [row[self.n] for row in self.A]
        n = len(b)

        # Step 1
        y = [0.0] * n
        for i in range(n):
            s = sum(self.round_sig(self.L[i][j] * y[j], self.precision) for j in range(i))
            y[i] = self.round_sig(((b[i] - s) / self.L[i][i]) , self.precision)

        # Step 2
        x = [0.0] * n
        for i in range(n - 1, -1, -1):
            s = sum(self.round_sig(self.U[i][j] * x[j], self.precision) for j in range(i + 1, n))
            x[i] = self.round_sig((y[i] - s) / self.U[i][i] , self.precision)
        
        return x