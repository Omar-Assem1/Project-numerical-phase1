# classes/forward_eliminator.py
class ForwardEliminatorScaling:
    def __init__(self, augmented_matrix):
        self.n = len(augmented_matrix)
        self.M = [row[:] for row in augmented_matrix]
        self.rank = 0
        self.pivot_positions = []

    def eliminate(self):
        print("\n" + "=" * 80)
        print("    GAUSSIAN ELIMINATION WITH SCALED PARTIAL PIVOTING")
        print("=" * 80)
        self._print("Initial Augmented Matrix")

        scale = [0.0] * self.n
        for i in range(self.n):
            row_max = max(abs(self.M[i][j]) for j in range(self.n))
            scale[i] = row_max if row_max > 0 else 1.0

        row = 0
        for col in range(self.n):
            if row >= self.n:
                break

            best_idx = row
            best_ratio = -1.0

            for i in range(row, self.n):
                ratio = abs(self.M[i][col]) / scale[i] if scale[i] > 0 else 0.0
                if ratio > best_ratio:
                    best_ratio = ratio
                    best_idx = i

            if best_ratio < 1e-12:
                continue

            if best_idx != row:
                print(f"\nSwap Row{row+1} ↔ Row{best_idx+1}  (scaled ratio = {best_ratio:.6f})")
                self.M[row], self.M[best_idx] = self.M[best_idx], self.M[row]
                scale[row], scale[best_idx] = scale[best_idx], scale[row]
                self._print()

            pivot = self.M[row][col]
            print(f"\nPivot → R{row+1},C{col+1} = {pivot:+.6f}  (scaled ratio = {best_ratio:.6f})")

            for i in range(row + 1, self.n):
                if abs(self.M[i][col]) > 1e-12:
                    factor = self.M[i][col] / pivot
                    print(f"Row{i+1} -= ({factor:.6f}) × Row{row+1}")
                    for j in range(col, self.n + 1):
                        self.M[i][j] -= factor * self.M[row][j]
                    self.M[i][col] = 0.0
                    self._print()

            self.pivot_positions.append((row, col))
            row += 1

        self.rank = row

        print("\n" + "=" * 80)
        print(f"           UPPER TRIANGULAR (ROW ECHELON) FORM")
        print(f"                    RANK = {self.rank}")
        print("=" * 80)
        self._print()

    def _print(self, message=""):
        
        if message:
            print(message)
        for i, r in enumerate(self.M):
            print(f"R{i+1}:", "  ".join(f"{x:12.4f}" for x in r))
        print()

    def get_result(self):
        return self.M, self.rank, self.pivot_positions