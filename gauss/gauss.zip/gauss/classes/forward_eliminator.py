# classes/forward_eliminator.py
class ForwardEliminator:
    """Performs Gaussian elimination with partial pivoting and computes rank"""
    def __init__(self, augmented_matrix):
        self.n = len(augmented_matrix)
        self.M = augmented_matrix                  # working copy
        self.rank = 0
        self.pivot_positions = []                  # list of (row, col)

    def eliminate(self):
        print("\n" + "=" * 75)
        print("        FORWARD ELIMINATION WITH PARTIAL PIVOTING")
        print("=" * 75)
        self._print("Initial Matrix")

        row = 0
        for col in range(self.n):
            # Find best pivot
            pivot_idx = None
            for i in range(row, self.n):
                if abs(self.M[i][col]) > 1e-10:
                    if pivot_idx is None or abs(self.M[i][col]) > abs(self.M[pivot_idx][col]):
                        pivot_idx = i

            if pivot_idx is None:
                continue

            # Swap rows
            if pivot_idx != row:
                print(f"\nSwap Row{row+1} Row{pivot_idx+1}")
                self.M[row], self.M[pivot_idx] = self.M[pivot_idx], self.M[row]
                self._print()

            pivot = self.M[row][col]
            print(f"\nPivot at position ({row+1},{col+1}) = {pivot:.6f}")

            # Eliminate below
            for i in range(row + 1, self.n):
                if abs(self.M[i][col]) > 1e-10:
                    factor = self.M[i][col] / pivot
                    print(f"Row{i+1} -= ({factor:.6f}) × Row{row+1}")
                    for j in range(col, self.n + 1):
                        self.M[i][j] -= factor * self.M[row][j]
                    self.M[i][col] = 0.0
                    self._print()

            self.pivot_positions.append((row, col))
            row += 1

        self.rank = row

        print("\n" + "=" * 75)
        print(f"           ROW ECHELON FORM  →  RANK = {self.rank}")
        print("=" * 75)
        self._print()

    def _print(self, msg=""):
        if msg:
            print(msg)
        for i, r in enumerate(self.M):
            print(f"R{i+1}:", "  ".join(f"{x:12.4f}" for x in r))
        print()

    def get_result(self):
        return self.M, self.rank, self.pivot_positions