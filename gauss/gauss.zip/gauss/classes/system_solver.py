# classes/system_solver.py
class SystemSolver:
    def __init__(self, echelon_matrix, rank, n, pivot_positions):
        self.M = echelon_matrix
        self.rank = rank
        self.n = n
        self.pivot_positions = pivot_positions

    def solve(self):
        # Check inconsistency
        for i in range(self.rank, self.n):
            if abs(self.M[i][self.n]) > 1e-8:
                print("\nNO SOLUTION – System is inconsistent")
                print(f"Row {i+1} → 0 = {self.M[i][self.n]:.6f}")
                return

        if self.rank < self.n:
            print(f"\nINFINITE SOLUTIONS ({self.n - self.rank} free variable(s))")
            pivot_cols = {col for _, col in self.pivot_positions}
            free = [j+1 for j in range(self.n) if j not in pivot_cols]
            print("Free variables:", ", ".join(f"x{v}" for v in free))
            return

        # Unique solution
        print("\nUNIQUE SOLUTION")
        x = [0.0] * self.n
        for i in range(self.n - 1, -1, -1):
            row = self.M[i]
            known_sum = sum(row[j] * x[j] for j in range(i + 1, self.n))
            x[i] = (row[self.n] - known_sum) / row[i]

        print("-" * 40)
        for i, val in enumerate(x, 1):
            print(f"x{i} = {val:15.8f}")
        print()