from typing import List
from .LUdecompose import LUDecomposer
class LUSolver:
    @staticmethod
    def solve(A: List[List[float]], b: List[float]) -> List[float]:
        L, U, P = LUDecomposer.decompose(A)
        n = len(A)

        # Permute b according to P: Pb
        Pb = [b[P[i]] for i in range(n)]

        y = [0.0] * n
        for i in range(n):
            y[i] = Pb[i]
            for j in range(i):
                y[i] -= L[i][j] * y[j]

        x = [0.0] * n
        for i in range(n - 1, -1, -1):
            x[i] = y[i]
            for j in range(i + 1, n):
                x[i] -= U[i][j] * x[j]
            x[i] /= U[i][i]

        return x