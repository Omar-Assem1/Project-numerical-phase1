# correct_lu_final.py
from typing import List, Tuple

class LUDecomposer:
    @staticmethod
    def decompose(A: List[List[float]]) -> Tuple[List[List[float]], List[List[float]], List[int]]:

        n = len(A)
        # Work on a copy of A
        A = [row[:] for row in A]
        P = list(range(n))                     # current row permutation

        # ---------- In-place Gaussian elimination with partial pivoting ----------
        for k in range(n):
            # Find pivot (largest absolute value in column k, from row k downward)
            pivot_row = max(range(k, n), key=lambda i: abs(A[i][k]))
            if abs(A[pivot_row][k]) < 1e-15:
                raise ValueError("Matrix is singular")

            # Swap rows k and pivot_row
            A[k], A[pivot_row] = A[pivot_row], A[k]
            P[k], P[pivot_row] = P[pivot_row], P[k]

            # Elimination
            for i in range(k + 1, n):
                multiplier = A[i][k] / A[k][k]      # this is l_ik
                A[i][k] = multiplier                # store multiplier in lower part
                for j in range(k + 1, n):
                    A[i][j] -= multiplier * A[k][j]

        # ---------- Extract clean L and U from the combined matrix ----------
        L = [[0.0] * n for _ in range(n)]
        U = [[0.0] * n for _ in range(n)]

        for i in range(n):
            L[i][i] = 1.0
            for j in range(n):
                if i > j:
                    L[i][j] = A[i][j]               # multipliers are already in A below diagonal
                else:
                    U[i][j] = A[i][j]               # diagonal and above are U

        return L, U, P