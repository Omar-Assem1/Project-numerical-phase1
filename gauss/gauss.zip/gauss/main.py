# main.py
from linear_system import LinearSystem
from classes.forward_eliminator import ForwardEliminator
from classes.system_solver import SystemSolver
from classes_for_gauss_jordan import *
from Dolittle.LUsolver import LUSolver
from chelosky_crout import *

def main():
    # 1. Input n and precision
    n = int(input("Enter number of equations (n): "))
    precision = int(input("Enter desired precision (number of decimal places): "))

    # Create system and input equations
    system = LinearSystem(n, precision)

    print(f"\nPlease enter {n} equations (each with {n} coefficients + 1 constant term):")
    print("Example: 2 1 3 10   → means 2x₁ + x₂ + 3x₃ = 10\n")

    while not system.is_complete():
        eq = input(f"Equation {system.current_row + 1}/{n}: ").strip()
        system.add_equation(eq)

    system.show("Your System (Augmented Matrix)")

    # Extract data
    augmented = system.copy_matrix()  # [A|b]
    A = [row[:n] for row in augmented]  # coefficient matrix
    b = [row[n] for row in augmented]  # right-hand side

    # Choose method
    print("\n" + "=" * 70)
    print("                LINEAR SYSTEM SOLVER")
    print("=" * 70)
    print("1. Gauss Elimination (Partial Pivoting)")
    print("2. Gauss-Jordan Elimination (RREF)")
    print("3. LU Doolittle + Partial Pivoting")
    print("4. Crout LU Decomposition")
    print("5. Cholesky")
    print("-" * 70)
    choice = int(input("Enter choice (1-5): "))

    show_steps = input("\nShow step-by-step operations? (y/n): ").strip().lower() == 'y'

    # Helper: silence prints if user doesn't want steps
    def silent_run(func):
        if not show_steps:
            import builtins
            original_print = builtins.print
            builtins.print = lambda *args, **kwargs: None
        try:
            func()
        finally:
            if not show_steps:
                builtins.print = original_print

    print("\n" + "=" * 80)

    # ==================================================================
    if choice == 1:  # Gauss Elimination
        print("GAUSS ELIMINATION WITH PARTIAL PIVOTING")
        print("=" * 80)
        elim = ForwardEliminator(augmented.copy())
        silent_run(elim.eliminate)
        echelon, rank, pivots = elim.get_result()
        solver = SystemSolver(echelon, rank, n, pivots)
        solver.solve()

    # ==================================================================
    elif choice == 2:  # Gauss-Jordan
        print("GAUSS-JORDAN ELIMINATION → REDUCED ROW ECHELON FORM")
        print("=" * 80)
        gj = GaussJordanEliminator(augmented.copy())
        silent_run(gj.eliminate)
        rref, rank, pivots = gj.get_rref_result()
        solver = RREFSolver(rref, rank, n, pivots)
        solver.solve()

    # ==================================================================
    elif choice == 3:  # LU Doolittle + Pivoting
        print("LU DECOMPOSITION (Doolittle + Partial Pivoting)")
        print("=" * 80)
        try:
            x = LUSolver.solve(A, b)
            print("UNIQUE SOLUTION:")
            print("-" * 50)
            for i, val in enumerate(x, 1):
                print(f"x{i} = {val:.{precision}f}")
            print("-" * 50)
        except Exception as e:
            print("Error (possibly singular matrix):", e)

    # ==================================================================
    elif choice == 4:  # Crout LU
        print("CROUT LU DECOMPOSITION (No Pivoting)")
        print("=" * 80)

        crout = Crout_LU(system.n, system.precision)
        # Copy the augmented matrix into Crout object
        crout.A = augmented.copy()

        # Run decomposition with steps
        silent_run(crout.compute_LU)

        if not show_steps:
            print("Crout LU decomposition completed (steps hidden).")

        # Solve system
        try:
            x = crout.solve()
            print("\nUNIQUE SOLUTION (via Crout LU):")
            print("-" * 50)
            for i, val in enumerate(x, 1):
                print(f"x{i} = {val:.{precision}f}")
            print("-" * 50)
        except Exception as e:
            print("Failed to solve (singular matrix or zero pivot):", e)

    # ==================================================================
    elif choice == 5:
        print("CROUT LU DECOMPOSITION (No Pivoting)")
        print("=" * 80)

        chelosky = Chelosky_LU(system.n, system.precision)
        # Copy the augmented matrix into Crout object
        chelosky.A = augmented.copy()

        # Run decomposition with steps
        silent_run(chelosky.compute_LU)

        if not show_steps:
            print("Chelosky LU decomposition completed (steps hidden).")

        # Solve system
        try:
            x = chelosky.solve()
            print("\nUNIQUE SOLUTION (via Chelosky LU):")
            print("-" * 50)
            for i, val in enumerate(x, 1):
                print(f"x{i} = {val:.{precision}f}")
            print("-" * 50)
        except Exception as e:
            print("Failed to solve (singular matrix or zero pivot):", e)


# ==================================================================
if __name__ == "__main__":
    main()